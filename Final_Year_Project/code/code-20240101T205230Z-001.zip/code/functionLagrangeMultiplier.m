function [deviation,powerAllocation]=functionLagrangeMultiplier(eigenvaluesTransmitter,totalPower,k,alpha)
%
%INPUT:
%eigenvaluesTransmitter = Vector with the active eigenvalues at the
%                         transmitter side
%totalPower             = Total power of the training sequence
%k                      = Vector with k parameter values as in Corollary 3
%alpha                  = Langrange multiplier value
%
%OUTPUT:
%deviation              = Difference between available power and used power
%powerAllocation        = Training power allocation from Corollary 3

%Compute power allocation based on Eq. (21) in Corollary 3
powerAllocation = sqrt(8*(1./alpha(:))*eigenvaluesTransmitter'/3).*cos(repmat((-1).^k*pi/3,[length(alpha) 1])-atan(sqrt(8*(1./alpha(:))*(eigenvaluesTransmitter.^3)'/27-1))/3)-repmat(1./eigenvaluesTransmitter',[length(alpha) 1]);

%Deviation between total available power and the power that is used
deviation = abs(totalPower-sum(powerAllocation,2));
